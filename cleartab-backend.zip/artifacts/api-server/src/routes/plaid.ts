import { Router } from "express";
import {
  Configuration,
  PlaidApi,
  PlaidEnvironments,
  Products,
  CountryCode,
} from "plaid";

const router = Router();

function getPlaidClient() {
  const clientId = process.env["PLAID_CLIENT_ID"];
  const secret = process.env["PLAID_SECRET"];
  const env = (process.env["PLAID_ENV"] ?? "sandbox") as keyof typeof PlaidEnvironments;

  if (!clientId || !secret) {
    throw new Error("PLAID_CLIENT_ID and PLAID_SECRET must be set");
  }

  const basePath = PlaidEnvironments[env] ?? PlaidEnvironments.sandbox;

  const config = new Configuration({
    basePath,
    baseOptions: {
      headers: {
        "PLAID-CLIENT-ID": clientId,
        "PLAID-SECRET": secret,
      },
    },
  });

  return new PlaidApi(config);
}

// ── POST /api/plaid/create-link-token ───────────────────────────────
// Creates a Plaid Link token for the frontend to initialise the Plaid Link flow.
router.post("/plaid/create-link-token", async (req, res) => {
  const { userId } = req.body as { userId?: string };

  try {
    const client = getPlaidClient();

    const response = await client.linkTokenCreate({
      user: { client_user_id: userId ?? "cleartab-user" },
      client_name: "ClearTab",
      products: [Products.Transactions],
      country_codes: [CountryCode.Us, CountryCode.Gb],
      language: "en",
    });

    res.json({ linkToken: response.data.link_token });
  } catch (err: unknown) {
    req.log.error({ err }, "plaid link token creation failed");
    res.status(502).json({ error: "Failed to create Plaid link token" });
  }
});

// ── POST /api/plaid/exchange-token ──────────────────────────────────
// Exchanges a public Plaid token for an access token, then fetches
// the last 6 months of transactions and identifies recurring charges.
router.post("/plaid/exchange-token", async (req, res) => {
  const { publicToken } = req.body as { publicToken?: string };

  if (!publicToken) {
    res.status(400).json({ error: "publicToken is required" });
    return;
  }

  try {
    const client = getPlaidClient();

    // Exchange public token
    const exchangeRes = await client.itemPublicTokenExchange({
      public_token: publicToken,
    });
    const accessToken = exchangeRes.data.access_token;

    // Fetch transactions from last 6 months
    const endDate = new Date().toISOString().split("T")[0]!;
    const startDate = new Date(Date.now() - 180 * 24 * 60 * 60 * 1000)
      .toISOString()
      .split("T")[0]!;

    const txRes = await client.transactionsGet({
      access_token: accessToken,
      start_date: startDate,
      end_date: endDate,
      options: { count: 500 },
    });

    const transactions = txRes.data.transactions;

    // Group by merchant and identify recurring (appears ≥2 times with similar amounts)
    const byMerchant = new Map<
      string,
      { amounts: number[]; dates: string[]; category: string }
    >();

    for (const tx of transactions) {
      const name = tx.merchant_name ?? tx.name;
      const key = name.toLowerCase().replace(/\s+/g, "");
      const existing = byMerchant.get(key);
      const category = tx.personal_finance_category?.primary ?? tx.category?.[0] ?? "Other";

      if (existing) {
        existing.amounts.push(Math.abs(tx.amount));
        existing.dates.push(tx.date);
      } else {
        byMerchant.set(key, {
          amounts: [Math.abs(tx.amount)],
          dates: [tx.date],
          category,
        });
      }
    }

    // Only return merchants that appear ≥2 times (recurring pattern)
    const recurring = [];
    for (const [, { amounts, dates, category }] of byMerchant) {
      if (amounts.length < 2) continue;

      // Use median amount as the representative charge
      const sorted = [...amounts].sort((a, b) => a - b);
      const median = sorted[Math.floor(sorted.length / 2)]!;

      // Rough frequency detection
      const sortedDates = [...dates].sort();
      const firstDate = new Date(sortedDates[0]!);
      const lastDate = new Date(sortedDates[sortedDates.length - 1]!);
      const daySpan =
        (lastDate.getTime() - firstDate.getTime()) / (1000 * 60 * 60 * 24);
      const avgDays = daySpan / (amounts.length - 1);

      const frequency =
        avgDays < 10
          ? "weekly"
          : avgDays < 35
            ? "monthly"
            : avgDays < 100
              ? "quarterly"
              : "annual";

      recurring.push({
        name: byMerchant.keys().next().value,
        amount: Math.round(median * 100) / 100,
        frequency,
        category,
        occurrences: amounts.length,
        lastCharge: sortedDates[sortedDates.length - 1],
      });
    }

    res.json({ recurring });
  } catch (err: unknown) {
    req.log.error({ err }, "plaid exchange token failed");
    res.status(502).json({ error: "Failed to process Plaid token" });
  }
});

export default router;
