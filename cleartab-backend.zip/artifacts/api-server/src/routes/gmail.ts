import { Router } from "express";
import { google } from "googleapis";

const router = Router();

function getOAuth2Client(overrideRedirectUri?: string) {
  const clientId = process.env["GMAIL_CLIENT_ID"];
  const clientSecret = process.env["GMAIL_CLIENT_SECRET"];
  const redirectUri =
    overrideRedirectUri ??
    process.env["GMAIL_REDIRECT_URI"] ??
    "urn:ietf:wg:oauth:2.0:oob";

  if (!clientId || !clientSecret) {
    throw new Error("GMAIL_CLIENT_ID and GMAIL_CLIENT_SECRET must be set");
  }

  return new google.auth.OAuth2(clientId, clientSecret, redirectUri);
}

// ── POST /api/gmail/token ───────────────────────────────────────────
// Exchanges an OAuth authorisation code for an access + refresh token.
// Never logs or stores email content.
router.post("/gmail/token", async (req, res) => {
  const { code, redirectUri } = req.body as {
    code?: string;
    redirectUri?: string;
  };

  if (!code) {
    res.status(400).json({ error: "code is required" });
    return;
  }

  try {
    const client = getOAuth2Client(redirectUri);

    const { tokens } = await client.getToken(code);

    res.json({
      accessToken: tokens.access_token,
      refreshToken: tokens.refresh_token,
      expiry: tokens.expiry_date,
    });
  } catch (err: unknown) {
    req.log.error({ err }, "gmail token exchange failed");
    res.status(502).json({ error: "Failed to exchange Gmail token" });
  }
});

// ── POST /api/gmail/scan ────────────────────────────────────────────
// Scans Gmail for subscription-related emails and returns a parsed list.
// Reads subject + sender only — never reads or stores email body content.
router.post("/gmail/scan", async (req, res) => {
  const { accessToken } = req.body as { accessToken?: string };

  if (!accessToken) {
    res.status(400).json({ error: "accessToken is required" });
    return;
  }

  try {
    const client = getOAuth2Client();
    client.setCredentials({ access_token: accessToken });

    const gmail = google.gmail({ version: "v1", auth: client });

    // Search for subscription/receipt emails
    const searchQuery = [
      "subject:(subscription OR receipt OR \"your order\" OR \"payment confirmation\" OR renewal OR invoice)",
      "newer_than:180d",
    ].join(" ");

    const listRes = await gmail.users.messages.list({
      userId: "me",
      q: searchQuery,
      maxResults: 80,
    });

    const messageIds = listRes.data.messages ?? [];

    // Fetch headers only (metadata format — never reads body)
    const parsed: Array<{
      name: string;
      amount: number | null;
      sender: string;
      date: string;
    }> = [];

    const seen = new Set<string>();

    await Promise.allSettled(
      messageIds.slice(0, 50).map(async (msg) => {
        if (!msg.id) return;

        const detail = await gmail.users.messages.get({
          userId: "me",
          id: msg.id,
          format: "metadata",
          metadataHeaders: ["Subject", "From", "Date"],
        });

        const headers = detail.data.payload?.headers ?? [];
        const get = (name: string) =>
          headers.find((h) => h.name?.toLowerCase() === name.toLowerCase())
            ?.value ?? "";

        const subject = get("Subject");
        const from = get("From");
        const date = get("Date");

        // Parse company name from sender
        const fromMatch = from.match(/^"?([^"<]+)"?\s*</);
        const company = fromMatch
          ? fromMatch[1].trim()
          : from.split("@")[0].trim();

        // Parse amount from subject
        const amountMatch = subject.match(/\$\s*(\d+(?:\.\d{1,2})?)/);
        const amount = amountMatch ? parseFloat(amountMatch[1]) : null;

        // Deduplicate by company name
        const key = company.toLowerCase().replace(/\s+/g, "");
        if (seen.has(key)) return;
        seen.add(key);

        // Filter out non-subscription senders
        const lowerSubject = subject.toLowerCase();
        const isSubscription =
          lowerSubject.includes("subscription") ||
          lowerSubject.includes("receipt") ||
          lowerSubject.includes("renewal") ||
          lowerSubject.includes("invoice") ||
          lowerSubject.includes("payment") ||
          lowerSubject.includes("charged") ||
          lowerSubject.includes("billing");

        if (isSubscription) {
          parsed.push({ name: company, amount, sender: from, date });
        }
      })
    );

    res.json({ subscriptions: parsed, emailCount: messageIds.length });
  } catch (err: unknown) {
    req.log.error({ err }, "gmail scan failed");
    res.status(502).json({ error: "Failed to scan Gmail" });
  }
});

export default router;
