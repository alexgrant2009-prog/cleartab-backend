import { Router, type IRouter } from "express";
import healthRouter from "./health";
import gmailRouter from "./gmail";
import plaidRouter from "./plaid";
import cancelRouter from "./cancel";

const router: IRouter = Router();

router.use(healthRouter);
router.use(gmailRouter);
router.use(plaidRouter);
router.use(cancelRouter);

export default router;
