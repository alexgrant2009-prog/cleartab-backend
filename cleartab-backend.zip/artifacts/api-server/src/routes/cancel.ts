import { Router } from "express";
import nodemailer from "nodemailer";

const router = Router();

// Known support email addresses for common services
const SUPPORT_ADDRESSES: Record<string, string> = {
  netflix: "info@account.netflix.com",
  spotify: "support@spotify.com",
  adobe: "support@adobe.com",
  hulu: "support@hulu.com",
  amazon: "cs-reply@amazon.com",
  apple: "support@apple.com",
  google: "support@google.com",
  dropbox: "support@dropbox.com",
  microsoft: "support@microsoft.com",
  linkedin: "support@linkedin.com",
};

function getTransport() {
  const host = process.env["SMTP_HOST"];
  const user = process.env["SMTP_USER"];
  const pass = process.env["SMTP_PASS"];

  if (!host || !user || !pass) {
    return null; // SMTP not configured — use mock mode
  }

  return nodemailer.createTransport({
    host,
    port: parseInt(process.env["SMTP_PORT"] ?? "587", 10),
    secure: process.env["SMTP_SECURE"] === "true",
    auth: { user, pass },
  });
}

function findSupportEmail(subscriptionName: string): string {
  const lower = subscriptionName.toLowerCase();
  for (const [key, email] of Object.entries(SUPPORT_ADDRESSES)) {
    if (lower.includes(key)) return email;
  }
  // Generic fallback: send to user themselves with instructions
  return "";
}

function buildCancellationEmail(
  subscriptionName: string,
  userEmail: string
): { subject: string; text: string; html: string } {
  const subject = `Cancellation Request — ${subscriptionName} Account`;

  const text = `
Hello ${subscriptionName} Support Team,

I am writing to request the immediate cancellation of my ${subscriptionName} subscription associated with the email address: ${userEmail}

Please confirm:
1. That my subscription has been cancelled effective immediately
2. That no further charges will be made to my payment method
3. That I will receive a confirmation email once the cancellation is processed

If there is any information you require to process this request, please contact me at the email address above.

Thank you for your assistance.

Best regards,
${userEmail}

---
This cancellation request was sent via ClearTab (cleartab.app).
`.trim();

  const html = `
<p>Hello <strong>${subscriptionName}</strong> Support Team,</p>
<p>I am writing to request the immediate cancellation of my <strong>${subscriptionName}</strong> subscription associated with the email address: <strong>${userEmail}</strong></p>
<p>Please confirm:</p>
<ol>
  <li>That my subscription has been cancelled effective immediately</li>
  <li>That no further charges will be made to my payment method</li>
  <li>That I will receive a confirmation email once the cancellation is processed</li>
</ol>
<p>If there is any information you require to process this request, please contact me at the email address above.</p>
<p>Thank you for your assistance.</p>
<p>Best regards,<br/>${userEmail}</p>
<hr/>
<small>This cancellation request was sent via <a href="https://cleartab.app">ClearTab</a>.</small>
`.trim();

  return { subject, text, html };
}

// ── POST /api/cancel/email ──────────────────────────────────────────
// Sends a cancellation email on behalf of the user to the subscription's
// support address. Falls back to a copy sent to the user if SMTP is not
// configured, or if the support address is unknown.
router.post("/cancel/email", async (req, res) => {
  const { subscriptionName, userEmail } = req.body as {
    subscriptionName?: string;
    userEmail?: string;
  };

  if (!subscriptionName || !userEmail) {
    res
      .status(400)
      .json({ error: "subscriptionName and userEmail are required" });
    return;
  }

  const supportEmail = findSupportEmail(subscriptionName);
  const { subject, text, html } = buildCancellationEmail(
    subscriptionName,
    userEmail
  );

  const transport = getTransport();

  // SMTP not configured — return mock success with the draft so the
  // client can show it to the user or handle it differently.
  if (!transport) {
    req.log.warn(
      { subscriptionName },
      "SMTP not configured — returning mock cancellation response"
    );
    res.json({
      success: true,
      mock: true,
      message:
        "SMTP is not configured. In production, configure SMTP_HOST, SMTP_USER, and SMTP_PASS to send real emails.",
      draft: {
        to: supportEmail || userEmail,
        subject,
        body: text,
      },
    });
    return;
  }

  try {
    const from = process.env["SMTP_FROM"] ?? process.env["SMTP_USER"];
    const to = supportEmail || userEmail; // fall back to user copy if no support address known
    const replyTo = userEmail;

    await transport.sendMail({ from, to, replyTo, subject, text, html });

    req.log.info(
      { subscriptionName, to },
      "cancellation email sent"
    );

    res.json({
      success: true,
      mock: false,
      message: `Cancellation email sent to ${to}`,
      sentTo: to,
    });
  } catch (err: unknown) {
    req.log.error({ err }, "failed to send cancellation email");
    res.status(502).json({ error: "Failed to send cancellation email" });
  }
});

export default router;
